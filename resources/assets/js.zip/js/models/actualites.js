var ModelActualites = Pclia.Collection.extend({
    model: ModelActualite,
});