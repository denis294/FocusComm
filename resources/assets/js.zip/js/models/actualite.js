var ModelActualite = Pclia.Model.extend({

});