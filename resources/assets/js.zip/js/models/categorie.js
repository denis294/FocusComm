var ModelCategorie = Pclia.Model.extend({

});