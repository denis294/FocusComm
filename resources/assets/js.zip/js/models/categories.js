var ModelCategories = Pclia.Collection.extend({
    model: ModelCategorie

});